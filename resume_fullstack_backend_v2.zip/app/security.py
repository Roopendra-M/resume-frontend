
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Literal
from jose import jwt, JWTError
from fastapi import HTTPException, Depends
from passlib.context import CryptContext
from app.config import settings
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = HTTPBearer(auto_error=False)

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(password: str, hashed: str) -> bool:
    return pwd_context.verify(password, hashed)

def create_access_token(subject: Dict[str, Any], expires_minutes: int = 60*24) -> str:
    to_encode = subject.copy()
    expire = datetime.utcnow() + timedelta(minutes=expires_minutes)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.JWT_SECRET, algorithm="HS256")

Authed = Dict[str, Any]

def get_current_user(token: HTTPAuthorizationCredentials = Depends(oauth2_scheme)) -> Authed:
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = jwt.decode(token.credentials, settings.JWT_SECRET, algorithms=["HS256"])
        return payload
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

def require_role(roles: list[str], authed: Authed = Depends(get_current_user)) -> Authed:
    if authed.get("role") not in roles:
        raise HTTPException(403, "Forbidden")
    return authed
