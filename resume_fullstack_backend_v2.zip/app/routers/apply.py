
from fastapi import APIRouter, HTTPException, Depends
from datetime import datetime
from bson import ObjectId
from app.db import db
from app.models import ApplyIn, ApplicationOut
from app.security import get_current_user
from app.utils import match_score

router = APIRouter(prefix="/api/apply", tags=["Apply"])

@router.post("/", response_model=ApplicationOut)
async def apply_job(payload: ApplyIn, authed=Depends(get_current_user)):
    job = await db.jobs.find_one({"_id": ObjectId(payload.job_id)})
    if not job:
        raise HTTPException(404, "Job not found")
    # Use the latest resume of the user if not provided
    resume = None
    if payload.resume_id:
        resume = await db.resumes.find_one({"_id": ObjectId(payload.resume_id), "user_id": authed["user_id"]})
    else:
        resume = await db.resumes.find_one({"user_id": authed["user_id"]}, sort=[("uploaded_at",-1)])
    if not resume:
        raise HTTPException(400, "Upload a resume first")
    score = match_score(resume.get("skills",[]), job.get("skills",[]))
    doc = {
        "user_id": authed["user_id"],
        "job_id": str(job["_id"]),
        "match_score": score,
        "created_at": datetime.utcnow(),
    }
    res = await db.applications.insert_one(doc)
    return ApplicationOut(id=str(res.inserted_id), job_id=str(job["_id"]), job_title=job["title"], match_score=score, created_at=doc["created_at"])

@router.get("/me", response_model=list[ApplicationOut])
async def my_applications(authed=Depends(get_current_user)):
    cur = db.applications.find({"user_id": authed["user_id"]}).sort("created_at",-1)
    out = []
    async for a in cur:
        job = await db.jobs.find_one({"_id": ObjectId(a["job_id"])})
        out.append(ApplicationOut(id=str(a["_id"]), job_id=a["job_id"], job_title=job["title"] if job else "Job", match_score=a["match_score"], created_at=a["created_at"]))
    return out
