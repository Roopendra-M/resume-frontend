
from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
from datetime import datetime
from app.db import db
from app.models import ResumeUploadOut
from app.security import get_current_user
from app.utils import extract_text_from_pdf, extract_text_from_docx, hf_extract_skills

router = APIRouter(prefix="/api/resume", tags=["Resume"])

@router.post("/upload", response_model=ResumeUploadOut)
async def upload_resume(file: UploadFile = File(...), authed=Depends(get_current_user)):
    content = await file.read()
    if file.filename.lower().endswith(".pdf"):
        text = extract_text_from_pdf(content)
    elif file.filename.lower().endswith(".docx"):
        text = extract_text_from_docx(content)
    else:
        raise HTTPException(400, "Unsupported file type")
    skills = await hf_extract_skills(text)
    doc = {
        "user_id": authed["user_id"],
        "filename": file.filename,
        "text": text,
        "skills": skills,
        "uploaded_at": datetime.utcnow()
    }
    res = await db.resumes.insert_one(doc)
    excerpt = (text[:300] + "...") if len(text) > 303 else text
    return ResumeUploadOut(id=str(res.inserted_id), filename=file.filename, text_excerpt=excerpt, skills=skills, uploaded_at=doc["uploaded_at"])
