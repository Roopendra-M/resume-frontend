
from fastapi import APIRouter, HTTPException, Depends
from datetime import datetime
from bson import ObjectId
from app.db import db
from app.models import JobCreate, JobOut
from app.security import require_role

router = APIRouter(prefix="/api/jobs", tags=["Jobs"])

@router.post("/", response_model=JobOut)
async def create_job(payload: JobCreate, authed=Depends(lambda: require_role(["admin"]))):
    doc = payload.dict()
    doc["created_at"] = datetime.utcnow()
    res = await db.jobs.insert_one(doc)
    return JobOut(id=str(res.inserted_id), created_at=doc["created_at"], **payload.dict())

@router.get("/", response_model=list[JobOut])
async def list_jobs():
    cur = db.jobs.find().sort("created_at", -1)
    out = []
    async for j in cur:
        out.append(JobOut(id=str(j["_id"]), title=j["title"], company=j["company"], location=j["location"], description=j["description"], skills=j.get("skills",[]), created_at=j["created_at"]))
    return out

@router.get("/{job_id}", response_model=JobOut)
async def get_job(job_id: str):
    j = await db.jobs.find_one({"_id": ObjectId(job_id)})
    if not j:
        raise HTTPException(404, "Job not found")
    return JobOut(id=str(j["_id"]), title=j["title"], company=j["company"], location=j["location"], description=j["description"], skills=j.get("skills",[]), created_at=j["created_at"])

@router.delete("/{job_id}")
async def delete_job(job_id: str, authed=Depends(lambda: require_role(["admin"]))):
    await db.jobs.delete_one({"_id": ObjectId(job_id)})
    return {"ok": True}
