
import io, re, pdfplumber
from docx import Document
from typing import List
import httpx
from app.config import settings

SKILL_KEYWORDS = [
    "python","java","javascript","react","node","fastapi","mongodb","docker","kubernetes",
    "aws","azure","gcp","sql","nosql","pandas","numpy","nlp","ml","ai","typescript","tailwind",
    "jira","git","linux","flask","django","rest","graphql"
]

def extract_text_from_pdf(data: bytes) -> str:
    with io.BytesIO(data) as f:
        text_all = []
        with pdfplumber.open(f) as pdf:
            for page in pdf.pages:
                text_all.append(page.extract_text() or "")
        return "\n".join(text_all)

def extract_text_from_docx(data: bytes) -> str:
    with io.BytesIO(data) as f:
        doc = Document(f)
        return "\n".join(p.text for p in doc.paragraphs)

def extract_skills(text: str) -> List[str]:
    text_l = text.lower()
    found = {s for s in SKILL_KEYWORDS if s in text_l}
    return sorted(found)

async def hf_extract_skills(text: str) -> List[str]:
    if not settings.HUGGINGFACE_API_KEY:
        return extract_skills(text)
    try:
        # simple zero-shot-like keyword suggestion using a small model endpoint (placeholder)
        # You can switch to a specific inference endpoint; here we fallback to local keyword scan.
        headers = {"Authorization": f"Bearer {settings.HUGGINGFACE_API_KEY}"}
        # Dummy call to ensure token is valid; we don't rely on response.
        async with httpx.AsyncClient(timeout=10) as client:
            await client.get("https://huggingface.co/api/whoami-v2", headers=headers)
        return extract_skills(text)
    except Exception:
        return extract_skills(text)

def match_score(resume_skills: List[str], job_skills: List[str]) -> float:
    if not job_skills:
        return 50.0
    rs = set(s.lower() for s in resume_skills)
    js = set(s.lower() for s in job_skills)
    inter = len(rs & js)
    return round(100.0 * inter / len(js), 2)
