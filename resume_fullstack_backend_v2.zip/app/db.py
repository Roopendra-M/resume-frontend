
from motor.motor_asyncio import AsyncIOMotorClient
from app.config import settings

client: AsyncIOMotorClient | None = None
db = None

async def init_db():
    global client, db
    client = AsyncIOMotorClient(settings.MONGO_URI)
    db = client[settings.DB_NAME]
    # indexes
    await db.users.create_index("email", unique=True)
    await db.jobs.create_index([("created_at", -1)])
    await db.applications.create_index([("user_id", 1), ("job_id", 1)], unique=False)

async def close_db():
    global client
    if client:
        client.close()
