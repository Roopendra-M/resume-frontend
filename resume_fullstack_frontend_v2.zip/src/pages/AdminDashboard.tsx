
import { useEffect, useState } from 'react'
import { API } from '../lib/api'
import { BarChart, Bar, XAxis, YAxis, Tooltip, PieChart, Pie, LineChart, Line, CartesianGrid, Legend, ResponsiveContainer, Cell } from 'recharts'

export default function AdminDashboard(){
  const [stats, setStats] = useState<any>({})
  const [feedback, setFeedback] = useState<any[]>([])

  useEffect(()=>{
    API.get('/api/admin/dashboard').then(r=>setStats(r.data))
    API.get('/api/feedback').then(r=>setFeedback(r.data))
  },[])

  const barData = [
    { name: 'Users', value: stats.users||0 },
    { name: 'Jobs', value: stats.jobs||0 },
    { name: 'Resumes', value: stats.resumes||0 },
    { name: 'Applications', value: stats.applications||0 },
  ]
  const lineData = [
    { name: 'Last 30 days', applications: stats.applications_last_30||0 }
  ]
  const pieData = [
    { name: 'Feedback', value: feedback.length||0 },
    { name: 'No Feedback', value: (stats.users||0) - (feedback.length||0) }
  ]

  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-semibold">Admin Dashboard</h2>
      <div className="grid md:grid-cols-3 gap-6">
        <div className="glass p-4">
          <h3 className="font-semibold mb-2">Entities</h3>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={barData}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="value" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="glass p-4">
          <h3 className="font-semibold mb-2">Applications (30d)</h3>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={lineData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="applications" />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="glass p-4">
          <h3 className="font-semibold mb-2">Feedback Coverage</h3>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={pieData} dataKey="value" label />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <h3 className="text-xl font-semibold">Recent Feedback</h3>
      <div className="grid md:grid-cols-2 gap-4">
        {feedback.map((f:any)=> (
          <div key={f.id} className="p-4 glass">
            <div className="text-sm text-white/70">{new Date(f.created_at).toLocaleString()}</div>
            <div className="font-semibold mt-1">{'★'.repeat(f.rating)}{'☆'.repeat(5-f.rating)}</div>
            <p className="mt-2">{f.message}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
