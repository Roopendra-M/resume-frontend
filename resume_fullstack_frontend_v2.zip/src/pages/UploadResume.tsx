
import { useState } from 'react'
import { API } from '../lib/api'

export default function UploadResume(){
  const [file, setFile] = useState<File|null>(null)
  const [result, setResult] = useState<any|null>(null)

  const submit = async (e:any)=>{
    e.preventDefault()
    if(!file) return
    const form = new FormData()
    form.append('file', file)
    const {data} = await API.post('/api/resume/upload', form, { headers: {'Content-Type':'multipart/form-data'}})
    setResult(data)
  }

  return (
    <div className="max-w-xl">
      <h2 className="text-2xl font-semibold mb-4">Upload Resume</h2>
      <form onSubmit={submit} className="p-4 glass space-y-3">
        <input type="file" accept=".pdf,.docx" onChange={e=>setFile(e.target.files?.[0]||null)} />
        <button className="px-4 py-2 rounded bg-indigo-600 hover:bg-indigo-500">Upload</button>
      </form>
      {result && (
        <div className="mt-4 p-4 glass">
          <div className="font-semibold">Parsed Skills</div>
          <div className="text-sm">{result.skills.join(', ') || 'None detected'}</div>
          <div className="text-xs text-white/60 mt-2">Excerpt: {result.text_excerpt}</div>
        </div>
      )}
    </div>
  )
}
