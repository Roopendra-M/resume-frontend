
import { useState } from 'react'
import { API } from '../lib/api'

export default function Feedback(){
  const [message,setMessage] = useState('')
  const [rating,setRating] = useState(5)
  const submit = async (e:any)=>{
    e.preventDefault()
    await API.post('/api/feedback/', { message, rating })
    setMessage('')
    alert('Thanks for your feedback!')
  }
  return (
    <div className="max-w-md">
      <h2 className="text-2xl font-semibold mb-4">Feedback</h2>
      <form onSubmit={submit} className="space-y-3 p-4 glass">
        <textarea className="w-full px-3 py-2 rounded glass" placeholder="Your thoughts..." value={message} onChange={e=>setMessage(e.target.value)} />
        <select className="px-3 py-2 rounded glass" value={rating} onChange={e=>setRating(parseInt(e.target.value))}>
          {[1,2,3,4,5].map(n=><option key={n} value={n}>{n}</option>)}
        </select>
        <button className="px-4 py-2 rounded bg-indigo-600 hover:bg-indigo-500">Submit</button>
      </form>
    </div>
  )
}
