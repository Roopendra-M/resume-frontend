
import { useEffect, useState } from 'react'
import { API } from '../lib/api'

export default function Jobs(){
  const [jobs, setJobs] = useState<any[]>([])
  const [title, setTitle] = useState('')
  const [company, setCompany] = useState('')
  const [location, setLocation] = useState('')
  const [description, setDescription] = useState('')
  const [skills, setSkills] = useState('')
  const role = localStorage.getItem('role')

  useEffect(()=>{ API.get('/api/jobs').then(r=>setJobs(r.data)) },[])

  const createJob = async (e:any)=>{
    e.preventDefault()
    const payload = { title, company, location, description, skills: skills.split(',').map(s=>s.trim()).filter(Boolean) }
    const {data} = await API.post('/api/jobs/', payload)
    setJobs([data, ...jobs])
    setTitle(''); setCompany(''); setLocation(''); setDescription(''); setSkills('')
  }

  const apply = async (job_id:string)=>{
    const {data} = await API.post('/api/apply/', { job_id })
    alert(`Applied with score: ${data.match_score}%`)
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold">Job Listings</h2>

      {role==='admin' && (
      <form onSubmit={createJob} className="glass p-4 grid sm:grid-cols-2 gap-3">
        <input className="px-3 py-2 rounded glass" placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} />
        <input className="px-3 py-2 rounded glass" placeholder="Company" value={company} onChange={e=>setCompany(e.target.value)} />
        <input className="px-3 py-2 rounded glass" placeholder="Location" value={location} onChange={e=>setLocation(e.target.value)} />
        <input className="px-3 py-2 rounded glass sm:col-span-2" placeholder="Skills (comma separated)" value={skills} onChange={e=>setSkills(e.target.value)} />
        <textarea className="px-3 py-2 rounded glass sm:col-span-2" placeholder="Description" value={description} onChange={e=>setDescription(e.target.value)} />
        <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 rounded w-max">Post Job</button>
      </form>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        {jobs.map(j=> (
          <div key={j.id} className="p-4 glass">
            <div className="font-semibold text-lg">{j.title}</div>
            <div className="text-white/70 text-sm">{j.company} • {j.location}</div>
            <div className="text-white/80 mt-2 line-clamp-3">{j.description}</div>
            <div className="text-xs text-white/60 mt-2">Skills: {j.skills?.join(', ')}</div>
            <div className="mt-3">
              <button onClick={()=>apply(j.id)} className="px-3 py-1 rounded bg-indigo-600 hover:bg-indigo-500">Apply</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
