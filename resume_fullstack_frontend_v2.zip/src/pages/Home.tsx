
import { Link } from 'react-router-dom'

export default function Home(){
  return (
    <div className="text-center">
      <h1 className="text-4xl font-bold">AI Resume Analyzer</h1>
      <p className="text-white/70 mt-2">Upload your resume, get skills extracted, and match with jobs.</p>
      <div className="mt-8 flex gap-3 justify-center">
        <Link to="/upload" className="px-4 py-2 rounded bg-indigo-600 hover:bg-indigo-500">Upload Resume</Link>
        <Link to="/jobs" className="px-4 py-2 rounded glass">Browse Jobs</Link>
      </div>
    </div>
  )
}
