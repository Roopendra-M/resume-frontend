
import { useState } from 'react'
import { API } from '../lib/api'
import { useNavigate } from 'react-router-dom'

export default function Login(){
  const [email,setEmail] = useState('')
  const [password,setPassword] = useState('')
  const nav = useNavigate()
  const submit = async (e:any)=>{
    e.preventDefault()
    const {data} = await API.post('/api/auth/login',{email,password})
    localStorage.setItem('token', data.access_token)
    localStorage.setItem('role', data.role)
    nav('/dashboard')
  }
  return (
    <div className="max-w-sm mx-auto">
      <h2 className="text-xl font-semibold mb-4">User Login</h2>
      <form onSubmit={submit} className="space-y-3">
        <input className="w-full glass px-3 py-2" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="w-full glass px-3 py-2" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="w-full bg-indigo-600 hover:bg-indigo-500 rounded py-2">Login</button>
      </form>
    </div>
  )
}
