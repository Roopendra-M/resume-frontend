
import { useEffect, useState } from 'react'
import { API } from '../lib/api'
import { Link } from 'react-router-dom'

export default function Dashboard(){
  const [apps, setApps] = useState<any[]>([])
  useEffect(()=>{
    API.get('/api/apply/me').then(r=>setApps(r.data))
  },[])
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Your Applications</h2>
      <div className="grid md:grid-cols-2 gap-4">
        {apps.map(a=> (
          <div key={a.id} className="p-4 glass">
            <div className="font-semibold">{a.job_title}</div>
            <div className="text-white/70 text-sm">Match Score: {a.match_score}%</div>
            <div className="text-white/60 text-xs">{new Date(a.created_at).toLocaleString()}</div>
          </div>
        ))}
      </div>
      <div className="mt-6">
        <Link to="/jobs" className="px-4 py-2 rounded bg-indigo-600 hover:bg-indigo-500">Find Jobs</Link>
      </div>
    </div>
  )
}
