
import { Outlet, Link, useNavigate } from 'react-router-dom'
import Footer from './Footer'

export default function Layout(){
  const nav = useNavigate()
  const token = localStorage.getItem('token')
  const role = localStorage.getItem('role')
  return (
    <div className="min-h-screen gradient-bg">
      <header className="sticky top-0 z-10 border-b border-white/10 bg-black/40 backdrop-blur-md">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="font-bold text-xl">Resume<span className="text-indigo-400">AI</span></Link>
          <nav className="flex gap-4 text-sm">
            <Link to="/jobs" className="hover:text-indigo-300">Jobs</Link>
            <Link to="/upload" className="hover:text-indigo-300">Upload</Link>
            <Link to="/feedback" className="hover:text-indigo-300">Feedback</Link>
            {role === 'admin' ? (
              <Link to="/admin/dashboard" className="hover:text-indigo-300">Admin</Link>
            ) : (
              <Link to="/dashboard" className="hover:text-indigo-300">Dashboard</Link>
            )}
          </nav>
          <div className="flex gap-2">
            {!token ? (
              <>
                <Link to="/login" className="px-3 py-1 rounded glass">Login</Link>
                <Link to="/signup" className="px-3 py-1 rounded glass">Signup</Link>
                <Link to="/admin" className="px-3 py-1 rounded glass">Admin</Link>
              </>
            ) : (
              <button onClick={()=>{localStorage.clear(); nav('/')}} className="px-3 py-1 rounded glass">Logout</button>
            )}
          </div>
        </div>
      </header>
      <main className="max-w-6xl mx-auto px-4 py-8">
        <Outlet />
      </main>
      <Footer />
    </div>
  )
}
